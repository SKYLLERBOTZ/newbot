exports.textunbanv1 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Mohon Buka Nomor Whatsapp Saya


Pesan : Kepada pihak WhatsApp yang bijaksana kenapa akun WhatsApp saya terblokir padahal aktifitas WhatsApp messenger saya normal normal saja mohon dibukakan kembali akun WhatsApp saya dengan ini saya cantumkan kode nomor akun WhatsApp messenger saya sekian banyak Terimakasih

Nomor Whatsapp : 628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv2 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Mohon Buka Nomor Whatsapp Saya

Pesan : Halo pak, Akun Whatsapp Saya diblokir Saya Maaf Saya Telah Menginstal Aplikasi Pihak Ketiga Secara Tidak Sengaja. Harap Buka Blokir Akun Saya Sesegera Mungkin. Terimakasih

Nomor Whatsapp : +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv3 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Please Open My WhatsApp Number

Pesan : Hello WhatsApp team, recently my WhatsApp number was suddenly blocked and I couldnt log into my account, in my account there is an important group like a school group and I have to read it but the account My WhatsApp is suddenly blocked, please restore my numbers : +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv4 = (prefix) => {
return `مرحبًا whatsapp ، تم حظر حسابي بشكل دائم أو مؤقت ، يرجى إلغاء حظر حسابي
الرقم`
}
//------------------------------------------------------------------\\
exports.textunbanv5 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Mohon Buka Nomor Whatsapp Saya

Pesan : Kepada pihak WhatsApp yang bijak Sana kenapa akun WhatsApp saya terblokir padahal aktifitas WhatsApp messenger saya normal normal saja mohon dibukakan kembali akun WhatsApp saya dengan ini saya cantumkan kode nomor akun WhatsApp messenger saya sekian banyak Terimakasih

Nomor Whatsapp : +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv6 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Mohon Buka Nomor Whatsapp Saya

Pesan : perdi meus documentos junto com meu telefone e cartão SIM. então eu quero que você desative meu número imediatamente fui hackeado tenho medo que alguém possa entrar na minha conta do whatsapp porque tem informações importantes sobre mim o número é

Número de WhatsApp: +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv7 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Por favor, abra el número de WhatsApp

Equipe, o sistema de vocês baniram meu número por engano. Peço que vocês reativem meu número pois tenho família em outro país e preciso me comunicar com eles

Número de WhatsApp: +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv8 = (prefix) => {
return `Dear WhatsApp, wise Sana, why is my WhatsApp account blocked, even though my WhatsApp messenger activities are normal, please reopen my WhatsApp account, I hereby include My WhatsApp messenger account number code, many thanks

Number Whatsapp : +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv9 = (prefix) => {
return `Olá, equipe do WhatsApp, meu número especial foi banido do whatsapp. Não fiz nada de errado ou não violei os termos e regras da política do WhatsApp. Meu número é

Número de WhatsApp: +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv10 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Assalamualaikum, الرجاء فتح رقم WhatsApp الخاص بي

Pesan : مرحباً. Assalamualaikum الرجاء حظر الرقم: (+628xxx). لقد تم خداع العديد من الضحايا من خلال هذا الحساب من خلال بيع منتجات كانت غير مبالية / رخيصة ، ولكن العديد منهم تعرضوا للخداع وتكبدوا خسائر فادحة لأن المنتجات المقدمة كانت مختلفة عن تلك المعروضة ، فقد احتجنا ولكن تم حظر أرقامنا من قبلهم. يرجى إعطاء عقوبة شديدة على هذا الرقم. شكرًا لك`
}
//------------------------------------------------------------------\\
exports.textunbanv11 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Assalamualaikum, الرجاء فتح رقم WhatsApp الخاص بي

Pesan : مرحباً. حساب تقرير السلام عليكم: [+628xxx]. يقوم الحساب بإجراء معاملات محظورة ، وهي الاحتيال في صورة اقتراض الأموال. لقد أبلغت القانون و WhatsApp ، الرجاء مساعدتنا ، يرجى حظر هذا الحساب من أجل سلامة هذه الأمة. نشكرك على العمل معًا لبناء دولة أكثر تقدمًا`
}
//------------------------------------------------------------------\\
exports.textunbanv12 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Assalamualaikum, الرجاء فتح رقم WhatsApp الخاص بي

Pesan مرحباً. أعزائي مسؤولي WhatsApp. الرجاء حظر الحساب: (+628xxx). انتهك الحساب سياسات whatsapp بشكل متكرر`
}
//------------------------------------------------------------------\\
exports.textunbanv13 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : مرحباً

Pesan : مرحبًا. لقد أبلغت عن الحساب: +628xxx لارتكاب عملية احتيال تحت ستار شرطي قام باعتقال زميلي وطلب من والدي الضحية بعض المال. طلب الحساب مليون روبية ، ولحسن الحظ أدرك والدا الضحية أنها كانت عملية احتيال. يرجى حظر الحساب حتى لا تحدث مثل هذه الحيل مرة أخرى`
}
//------------------------------------------------------------------\\
exports.textunbanv14 = (prefix) => {
return `Kepada : smb@support.whatsapp.com
Subjek : Assalamualaikum, الرجاء فتح رقم WhatsApp الخاص بي

Pesan : مرحبًا ، بصفتي مستخدم WhatsApp ، أريد الإبلاغ عن الرقم: (+628xxx) بريد عشوائي مع كتالوج يحتوي على رسائل وأسعار غريبة ويجعل WhatsApp يتأخر ويخرج من التطبيق ، يرجى حظر الحساب حتى لا يقع الكثير من الضحايا. البريد العشوائي الذي يمكن أن يضر بمستخدمي WhatsApp الآخرين. شكرًا لك`
}
//------------------------------------------------------------------\\
exports.textunbanv15 = (prefix) => {
return `

Olá WhatsApp, boa noite, estou aqui, quero solicitar acesso ao meu WhatsApp, pois bloqueei sem querer o número de um amigo meu e usei o batton do aplicativo bloquear e restaurar.  O WhatsApp do meu amigo e o bloqueio da conta do meu amigo é contra usar o WhatsApp e acessá-lo novamente e o número do meu amigo é +62xxx Obrigado
`
}
//------------------------------------------------------------------\\
exports.textunbanv16 = (prefix) => {
return `hello WhatsApp, my favorite number was suddenly blocked without a reason I did nothing wrong regarding privacy and terms of WhatsApp I beg you to review and unblock my account immediately, my number is +62`
}
//------------------------------------------------------------------\\
exports.textunbanv17 = (prefix) => {
return `
Saluton Bonan Posttagmezon Whatsapp-Subteamo Mi ŝatus peti ke mia Whatsapp-konto estu malfermita ĉar mi volas kontakti miajn parencojn kiuj estas eksterlande, ĉar mia avino mortis ĉe ŝia domo, bonvolu reaktivigi mian WhatsApp-konton, mi promesas, ke mi ne estos senatenta. denove, sed estas tre grave kontakti mian familion, mi petas vin remalfermi mian WhatsApp-konton, jen la telnumero +62xxxx, mi denove petas remalfermi mian WhatsApp-konton, mi petas, ddankon`
}
//------------------------------------------------------------------\\
exports.textunbanv18 = (prefix) => {
return `
হ্যালো প্রিয় হোয়াটসঅ্যাপ টিম, আমি এইমাত্র ওয়াহটসঅ্যাপ অ্যাপ্লিকেশনটি ব্যবহার করেছি, তাই আমি জানি না যে হোয়াটসঅ্যাপ অ্যাপ্লিকেশনের জন্য কী নিয়মগুলি রাখা হচ্ছে, এবং যখন আমি হোয়াটসঅ্যাপ অ্যাপ্লিকেশনটিতে লগ ইন করি তখন এটি বলে, স্প্যামের কারণে আপনার অ্যাকাউন্টটি ব্লক করা হয়েছে , আমি স্প্যাম বা অন্য কিছু করিনি, এবং আমি আপনাকে আমার হোয়াটসঅ্যাপ অ্যাকাউন্ট পুনরায় খুলতে অনুরোধ করছি, আমার বয়স 68 বছরের বেশি আগামীকাল আমার 69 তম জন্মদিন, আমাকে আমার বাড়িতে আসতে আমার পরিবারের সাথে যোগাযোগ করতে হবে, এখানে আমার ফোন নম্বর রয়েছে +62xxxx, ধন্যবাদ
`
}
//------------------------------------------------------------------\\
exports.textunbanv19 = (prefix) => {
return `HALO SAYA ADALAH PENGGUNA APLIKASI WHATSAPP, DAN SAYA SEKARANG SEDANG DALAM KULIAH, DAN DATA DATA KULIAH SAYA BERADA DI APLIKASI WHATSAPP, DAN SECARA TIBA TIBA AKUN WHATSAPP SAYA TERBLOKIR, SAYA HANYA MENGGUNAKAN APLIKASI WHATAAPP UNTUK CHATAN DAN TELPONAN, DAN SAYA TIDAK PERNAH SEKALI PUN MELANGGAR PERATURAN WAHTSAPP, TOLONG AKTIFKAN KEMBALI AKUN WHATSAPP SAYA, INI NOMOR AKUN WHATSAPP SAYA +62XXXX, TERIMA KASIH`
}
//------------------------------------------------------------------\\
exports.textunbanv20 = (prefix) => {
return `Kepada pihak WhatsApp yang bijak Sana kenapaakun WhatsApp saya terblokik padahal aktifitas WhatsApp messenger saya normal normal saja mohon dibukakan kembali akun WhatsApp saya dengan ini saya cantumkan kode nomor akun WhatsApp messenger saya sekian banyak Terimakasih

Nomor Whatsapp : +628xxx`
}
//------------------------------------------------------------------\\
exports.textunbanv21 = (prefix) => {
return `Halo pak, Akun Whatsapp Saya diblokir Saya Maaf Saya Telah Menginstal Aplikasi Pihak Ketiga Secara Tidak Sengaja. Harap Buka Blokir Akun Saya Sesegera Mungkin. Terimakasih

Nomor Whatsapp : +628xxx`
}
//------------------------------------------------------------------\\