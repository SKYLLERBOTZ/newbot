exports.textunbanpremv1 = (prefix) => {
return `Kepada : support@support.whatsapp.com
note : KIRIM LEWAT TINJAUAN WA

Pesan : ہیلو واٹس ایپ میرا واٹس ایپ نمبر بلا وجہ بلاک کر دیا گیا۔ براہ کرم میرا واٹس ایپ نمبر دوبارہ فعال کریں کیونکہ اس نمبر میں میرا بہت سا ذاتی ڈیٹا ہے جو میں اس نمبر کے نیچے محفوظ کرتا ہوں اور میں اس نمبر کو اپنے دفتری کاموں کے لیے بھی استعمال کرتا ہوں جو بہت اہم ہے۔ برائے مہربانی میرا واٹس ایپ نمبر جلد از جلد دوبارہ فعال کریں۔ شکریہ`

}
//✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗✗//
exports.textunbanpremv2 = (prefix) => {
return `Kepada : support@support.whatsapp.com
note : KIRIM LEWAT GMAIL / WEB
subjek : GAK USA DI ISI!

Pesan :  ہیلو واٹس ایپ میرا واٹس ایپ نمبر بلا وجہ بلاک کر دیا گیا۔ براہ کرم میرا واٹس ایپ نمبر دوبارہ فعال کریں کیونکہ اس نمبر میں میرا بہت سا ذاتی ڈیٹا ہے جو میں اس نمبر کے نیچے محفوظ کرتا ہوں اور میں اس نمبر کو اپنے دفتری کاموں کے لیے بھی استعمال کرتا ہوں جو بہت اہم ہے۔ برائے مہربانی میرا واٹس ایپ نمبر جلد از جلد دوبارہ فعال کریں۔ شکریہ. پیر نمبر واٹس ایپ: +62××××××××`

}
exports.textunbanpremv3 = (prefix) => {
return `Kepada : support@support.whatsapp.com
note : KIRIM LEWAT GMAIL ! 
Subjek : GAK USA DI ISI

Pesan : hello, why is my WhatsApp suddenly blocked, I can't get notifications, please restore my number +62×××××××`

}